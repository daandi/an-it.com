case class Book( title: String, pages: Int, year: Int)

val books = List( Book("Programming Scala", 883, 2012), Book("Programming Pearl", 1104, 2000), Book("Necronomicon",666,666),"Ein String", 5, 42 )

val bookComments = books.map( book => book match {
	case Book("Programming Scala", pages, year) => "New Scala Book by Martin Odersky from " + year
	case Book(title, pages,year) => title + " " + pages + " " + year
	case x: Int if x > 10 => "an inteeger bigger than 10"
	case _ => "Something else"
})
