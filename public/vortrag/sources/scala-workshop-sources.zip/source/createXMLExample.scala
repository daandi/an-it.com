case class Book( title: String, pages: Int, year: Int) {
	def toXML = 
		<book>
			<title>{title}</title>
			<pages>{pages}</pages>
			<year>{year}</year>
		</book>
	
	implicit def intToString(in : Int) : String =  in.toString
}

val books = List( Book("Programming Scala", 883, 2012), Book("Programming Pearl", 1104, 2000), Book("Necronomicon",666,666) )

for ( book <- books) {
	println(book.toXML)
}
