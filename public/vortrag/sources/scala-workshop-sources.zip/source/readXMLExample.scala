case class Book( title: String, pages: Int, year: Int) {
	def toXML = 
		<book>
			<title>{title}</title>
			<pages>{pages}</pages>
			<year>{year}</year>
		</book>
	
	implicit def intToString(in : Int) : String =  in.toString
}

object Book {
	def fromXML(bookXML: scala.xml.NodeSeq) : Book= {
		val title = (bookXML \\ "title").text
		val pages = (bookXML \\ "pages").text.toInt
		val year = (bookXML \\ "year").text.toInt
		new Book(title, pages, year)
	}
}

val books = 
<books>
	<book>
		<title>Programming Scala</title>
		<pages>883</pages>
		<year>2012</year>
	</book>
	<book>
		<title>Programming Pearl</title>
		<pages>1104</pages>
		<year>2000</year>
	</book>
	<book>
		<title>Necronomicon</title>
		<pages>666</pages>
		<year>666</year>
	</book>
</books>

(books \\ "book").map(Book.fromXML(_))

