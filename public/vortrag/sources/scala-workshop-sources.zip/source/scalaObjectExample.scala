object DeepThought {
	val theMeaningOfLife ="The meaning of life: 42"
	def speak { println(theMeaningOfLife)}
}