class Document(val title: String, val author: String, yearString: String) {

	val year = yearString.toString
	
	def shortCitation: String = author + " : " + title + ". " + year
}

val scalaBook = new Document("Programming In Scala","Martin Odersky","2011")
println(scalaBook.title)
println(scalaBook.year)