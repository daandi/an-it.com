class Name(argument: Typ) { 
  val member: Int = 42
  println("still constructing the class")
  
  def aMethod {}
}
