import org.specs2.matcher.XmlMatchers
import org.specs2.Specification
import org.specs2.specification.Fragments

import dispatch._
import Defaults._
/**
 * User: andi
 * Date: 11.12.13
 * Time: 15:31
 */
class DispatchExampleSpec extends Specification with XmlMatchers {def is: Fragments = s2"""
works without net connection
  transform XML to Editions                                     $toEditions
  build api call                                                $buildApiCall

needs working connection to the Internets
  get XML by ISBN                                               $getEditionsXML
  compare ISBNs by differing titles                             $getDifferingTitles

  """

def toEditions = DispatchExample.parseEditions(<rsp xmlns="http://worldcat.org/xid/isbn/" stat="ok">
  <isbn lang="eng" title="Rivers of London.">978-0-575-09758-2</isbn>
  <isbn lang="eng" title="Rivers of London">978-0-575-09759-9</isbn>
  <isbn lang="eng" title="Rivers of London">978-0-575-09757-5</isbn>
  <isbn lang="eng" title="Rivers of London">978-0-575-09756-8</isbn>
</rsp>) must containAllOf(List(Edition("Rivers of London","","eng","978-0-575-09759-9","")))

  def buildApiCall = DispatchExample.apiCallFor("123") mustEqual "http://xisbn.worldcat.org/webservices/xid/isbn/123?method=getEditions&format=xml&fl=title,year,lang,ed"

  def getEditionsXML = DispatchExample.getEditionsXml("978-0981531649")() must beEqualToIgnoringSpace(
  <rsp xmlns="http://worldcat.org/xid/isbn/" stat="ok">
    <isbn year="2010" lang="eng" ed="2nd ed." title="Programming in Scala">978-0-9815316-4-9</isbn>
    <isbn year="2008" lang="eng" ed="1st ed., version 9" title="Programming in Scala">978-0-9815316-0-1</isbn>
  </rsp>)

  def getDifferingTitles = {
    val  (r1,_,firstIsBigger) =DispatchExample.whichISBNhasMoreDifferingTitles("978-0061020612","978-0-9815316-4-9")()

    r1 must havePair("Witches abroad a novel of Discworld" -> List(
      Edition("Witches abroad a novel of Discworld","2007","eng","978-0-06-143393-1",""),
      Edition("Witches abroad a novel of Discworld","2007","eng","978-0-06-180972-9",""),
      Edition("Witches abroad a novel of Discworld","2007","eng","978-0-06-143392-4",""))
    )

    firstIsBigger must beTrue
  }


}
