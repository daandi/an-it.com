import org.specs2.Specification

/**
 * User: andi
 * Date: 11.12.13
 * Time: 15:00
 */
class EditionSpec extends Specification{def is = s2"""
Editions can be build from EditionXML                         $fromXML
"""

def fromXML =
  Edition fromXML <isbn year="1992" lang="eng" ed="[New ed., Nachdr.]" title="Witches abroad">978-0-552-15296-9</isbn> mustEqual Edition("Witches abroad","1992","eng","978-0-552-15296-9","[New ed., Nachdr.]")





}
