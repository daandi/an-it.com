/**
 * User: andi
 * Date: 11.12.13
 * Time: 14:33
 */

import dispatch._
import Defaults._
import scala.xml.NodeSeq

object DispatchExample {

  val isbns = List("978-0981531649", "978-1934356081")

  def apiCallFor(isbn: String) : String =
    s"http://xisbn.worldcat.org/webservices/xid/isbn/$isbn?method=getEditions&format=xml&fl=title,year,lang,ed"

  def parseEditions(xml: NodeSeq) : Seq[Edition] = for ( editionXML <- xml \\ "isbn") yield Edition fromXML editionXML

  def getEditionsXml(isbn: String) : Future[NodeSeq] = Http( url( apiCallFor(isbn)) OK as.xml.Elem  )

  def getEditions(isbn: String) = getEditionsXml( isbn) map parseEditions

  def whichISBNhasMoreDifferingTitles(isbn1: String, isbn2: String) = {

    def editionsByTitle(in : Seq[Edition]) = in groupBy (ed => ed.title)

    val ed1 = getEditions(isbn1) map editionsByTitle
    val ed2 = getEditions(isbn2) map editionsByTitle

    for (e1 <- ed1; e2 <- ed2) yield (e1,e2, e1.keys.size > e2.keys.size)


  }

  def example  = {

    val edF1 = getEditions("978-0981531649")
    val edF2 = getEditions("978-1934356081")

    for (ed1 <- edF1; ed2 <- edF2) yield (ed1.size,ed2.size)



  }

}
