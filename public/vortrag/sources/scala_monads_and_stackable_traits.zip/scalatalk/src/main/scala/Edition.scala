import scala.xml.NodeSeq

/**
 * User: andi
 * Date: 11.12.13
 * Time: 14:56
 */
case class Edition(title: String, year: String, lang: String, isbn: String, ed: String)

object Edition{
  def fromXML(xml: NodeSeq) : Edition =
    Edition(
      title = (xml \ "@title").text,
      year  = (xml \ "@year").text,
      ed    = (xml \ "@ed"  ).text,
      lang  = (xml \ "@lang").text,
      isbn  = xml.text
    )

}
