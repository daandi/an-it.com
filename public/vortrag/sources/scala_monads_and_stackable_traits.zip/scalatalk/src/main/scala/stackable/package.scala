/**
 * Date: 12.12.13
 * Time: 09:50
 */
package object stackable {


  type Extractions =  Map[String,Extraction]


  trait Extractors {
    def process : Extractions
  }

  class RuleExtractors extends Extractors{

    def process : Extractions = {
      // Message
      println("I'm a stupid Rule based Extraction System")

      Map(
        "name" -> Extraction("Andi","rule"),
        "amount" -> Extraction("2.50 €", "rule"),
        "bic" -> Extraction("ABCEDFG","rule")
      )
    }
  }

  trait TemplatingOverwrite extends Extractors{

    abstract override def process : Extractions = {
      println("I use mighty templates")
      super.process ++ Map("amount" -> Extraction("2500 €","temlating"))
    }

  }

  trait BICNameDatabase extends Extractors{

    lazy val oldExtractions =  super.process

    val bicNameDB = Map("ABCEDFG" -> "cristof")

    def lookUpExtraction : Option[Extraction] = for {
          Extraction(bic,_) <- oldExtractions get "bic"
          name              <- bicNameDB get bic
        } yield Extraction(name,"BICNameStore")


    abstract override def process : Extractions = {
      println("I use a BICStore to find the right names")
      lookUpExtraction map (ex => oldExtractions ++ Map("name" -> ex) ) getOrElse oldExtractions
    }

  }

}
