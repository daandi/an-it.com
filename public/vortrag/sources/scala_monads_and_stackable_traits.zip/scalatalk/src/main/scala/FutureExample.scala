import scala.util.{Failure, Success, Random}
import scala.concurrent._
import scala.concurrent.duration._
import ExecutionContext.Implicits.global

import scala.concurrent.duration.Duration._

/**
 * Date: 10.12.13
 * Time: 11:25
 */
object FutureExample {

  val failedFuture: Future[Int] = Promise[Int].failure(  new Exception("I am ERROR")).future

  def futureThatTakes[T](secondsToRun: Int)(resultAfter: T): Future[T] = future {
    blocking( Thread.sleep( secondsToRun * 1000))
    resultAfter
  }

  def futureInt : Future[Int] = future { Random.nextInt() }

  def getFutureIntInt = {
    val i = futureInt

    Await.result(i, 1 second)
  }

  def combineFuture = {
    val aF = futureInt
    val bF = futureInt

    for ( a <- aF ; b <- bF ) yield a.toDouble / b

  }


  def printFuture[T](f: Future[T]) = f onComplete {
  	case Success(t) => println(t)
  	case Failure(f) => throw f
  }


  def callbackExample = {
    val a1 = futureThatTakes(10)("Ich brauche zehn Sekunden.")
    val a2 = futureThatTakes(5)("Ich brauche fünf Sekunden.")
    val a3 = futureThatTakes(11)("Ich brauche elf Sekunden.")

    val fs : List[Future[String]] = List(a1,a2,a3)

    fs map printFuture

  }

  def awaitExample = {

    Await.result(futureThatTakes(10)("Ich brauche zehn Sekunden."), 5 seconds)

    Await.result(futureThatTakes(10)("Ich brauche zehn Sekunden."), 10 seconds)

    Await.result(futureSeq, 12 seconds)


  }

  lazy val futureSeq = Future.sequence(
    List(
      futureThatTakes(10)("Ich brauche zehn Sekunden."),
      futureThatTakes(5)("Ich brauche fünf Sekunden."),
      futureThatTakes(12)("Ich brauche zwölf Sekunden.")
    )
  )

  /**
  * scala> Await.result(combined, 11 seconds)
  * warning: there were 1 feature warning(s); re-run with -feature for details
  * java.util.concurrent.TimeoutException: Futures timed out after [11 seconds]
  */
  def combineDonewrong = {
  	val combined = for {
  		f1 <- futureThatTakes(10)("Ich brauche zehn Sekunden.")
      	f2 <- futureThatTakes(5)("Ich brauche fünf Sekunden.")
  	} yield f1 + f2

  	Await.result(combined, 11 seconds)
  }



  // right

  def combineDoneright = {
  	val fF1 = futureThatTakes(10)("Ich brauche zehn Sekunden.")
  	val fF2 = futureThatTakes(5)("Ich brauche fünf Sekunden.")

  	val combined = for {
  		f1 <- fF1
      f2 <- fF2
  	} yield f1 + f2

  	Await.result(combined, 11 seconds)
  }

  /**
  * scala> Await.result(combined, 11 seconds)
  * warning: there were 1 feature warning(s); re-run with -feature for details
  * res7: String = Ich brauche zehn Sekunden.Ich brauche fünf Sekunden.
  */






  

}
