package stackable

/**
 * Date: 12.12.13
 * Time: 10:27
 */
case class Extraction(value: String, src: String)
