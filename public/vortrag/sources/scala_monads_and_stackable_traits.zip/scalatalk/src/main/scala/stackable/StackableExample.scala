package stackable

/**
 * Date: 12.12.13
 * Time: 10:12
 */
object StackableExample {


  def exampleRule = new RuleExtractors process

  def extractorsWithTemplating = new RuleExtractors with TemplatingOverwrite process

  def dbExtractors = new RuleExtractors with BICNameDatabase process

  def fullMonty = new RuleExtractors with BICNameDatabase with TemplatingOverwrite



}
