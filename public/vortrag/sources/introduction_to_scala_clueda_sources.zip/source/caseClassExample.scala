case class Book(title: String, pages :Int)
//defined class Book

val book = Book("Necronomicon",1000)
//book: Book = Book(Necronomicon,1000)

println( book.title )
//Necronomicon

book == Book("Necronomicon",1000)
//Boolean = true

scala> book.hashCode
//-364191203

scala> Book("Necronomicon",1000).hashCode
//-364191203