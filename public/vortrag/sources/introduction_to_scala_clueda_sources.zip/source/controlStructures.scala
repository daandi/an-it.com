object ControlStructures {
  def unless( test: => Boolean)(action: => Any) = 
    if (! test) {action}

  def times( n: Int )(action: => Unit) {
    (1 to n).foreach { i => action}
  }
}


import ControlStructures._

times(2) { println("Hoorray :)")}

unless (5 < 10) { println("Math stopped working.") }

val ifNot = unless (2 + 2 != 4) { "Math still works." }