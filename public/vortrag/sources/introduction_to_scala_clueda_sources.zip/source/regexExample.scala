import scala.io.Source

val html = (Source fromURL "http://www.an-it.com").getLines mkString ""

val urlExtractor = """href\s?=\s?"([^"]+)"""".r


(urlExtractor findAllIn html).
  matchData foreach {
    case urlExtractor(url) => println(s"Url -> $url")
  }
