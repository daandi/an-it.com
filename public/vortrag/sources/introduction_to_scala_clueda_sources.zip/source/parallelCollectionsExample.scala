(1 to 10) foreach println
(1 to 10).par foreach println

// Unordered
val tenTimes = (1 to 10).par map (_ * 10) 
tenTimes foreach println

//Ordered
//.seq  transforms a parallel collection to a sequential one
tenTimes.seq foreach println