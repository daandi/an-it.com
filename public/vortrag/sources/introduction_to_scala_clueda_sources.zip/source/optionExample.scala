val bigBangPHD = Map(
  "Leonard" -> "Ph.D.",
  "Sheldon" -> "Ph.D.,Sc.D",
  "Rajesh" -> "Ph.D"
)

val friends = List("Leonard","Sheldon","Rajesh","Howard")

// Liste mit Options erzeugen
friends map bigBangPHD.get


// flatten entfernt None und „entpackt“ Some(thing)
friends.map(bigBangPHD.get(_)).flatten
friends flatMap ( f => bigBangPHD.get(f) )

// for comprehensions wenden Operationen nur auf Some() an und verwerfen
for {
	person <- friends
	phd <- bigBangPHD get person
} yield s"$person has a $phd"

// getOrElse erlaubt es einen Standardrückgabewert für None anzugeben, ansonsten wird Some(thing) „ausgepackt“
friends.
  map( n =>(n,bigBangPHD.get(n)) ). // creates Tuple
  map{ case (n,d) => 
				n + " " + d.getOrElse("Sheldon tells me you only have a master's degree.")
	}


// Option Types besitzen Extraktoren für Pattern Matching
friends map bigBangPHD.get zip friends map {
  case (Some(phd), name ) => name + " : " + phd
  case (None, name) => name + " is just an engineer"
}
