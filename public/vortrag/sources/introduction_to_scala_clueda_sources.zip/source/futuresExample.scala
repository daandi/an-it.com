import scala.io.Source
import scala.concurrent._
import scala.concurrent.duration._
import ExecutionContext.Implicits.global

val urls = List("http://www.clueda.de","http://www.neumann.biz","http://www.an-it.com")
val urlExtractor = """href\s?=\s?"([^"]+)"""".r

def now = System.currentTimeMillis

def getData(url: String) : String = Source.fromURL(url).mkString("")
def extractURLs(data: String) : Iterator[String] =
	urlExtractor.findAllIn(data).collect {
		case urlExtractor(url) => s"Url -> $url"
	}

def getLinks(url: String) : List[String] = extractURLs(getData(url)).toList
def getAndPrintLinks(url: String) : Unit = getLinks(url) foreach println

def takeTime[A]( fun : => A ) : (String,A) = {
	val start = now
	val result = fun
	val measurment =  s"took ${(now - start).toDouble / 1000} s"
	(measurment, result)
}


def printURLs(data: String) : Unit = extractURLs(data) foreach println
def printLinks = urls map ( url => printURLs( getData(url) ) )

def composedFutures: Future[(Unit,Unit,Unit)] = {
	val f1 = Future( getAndPrintLinks("http://www.an-it.com") )
	val f2 = Future( getAndPrintLinks("http://www.neumann.biz") )
	val f3 = Future( getAndPrintLinks("http://www.clueda.com") )

	for {
		d1 <- f1
		d2 <- f2
		d3 <- f3
	} yield (d1,d2,d3)
}

def normal = takeTime( printLinks )
def future = takeTime( Future(printLinks) )
def futureWait = takeTime( Await.result( Future(printLinks), 10 seconds ))
def composedWait = takeTime {  Await.result(composedFutures,10 seconds) }
