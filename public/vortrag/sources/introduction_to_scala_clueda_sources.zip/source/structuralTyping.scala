class Cowboy { def shout = "Yehaaw !" }
class Pirate { def shout = "Arrrgh !" }

def sayHelloTo( person : { def shout: String} ) =
	s"Me : Hello!\n $person shouts ${person.shout}"

val guybrush = new Pirate
val johnWayne = new Cowboy

sayHelloTo(guybrush)

sayHelloTo(johnWayne)
