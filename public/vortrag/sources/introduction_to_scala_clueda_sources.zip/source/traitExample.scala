trait Edible {
	def taste: String
	def eat = println(taste)
}

trait ExoticTaste {
	def eat: Unit

	def describeTaste = {
		eat
		println("It tastes exotic")
	}
}

case class Cake() extends Edible {
	def taste = "sweet"
}

case class ChilliChoc(taste: String) extends Edible with ExoticTaste

val cake = new Cake()
cake.eat

val chilliChoc = ChilliChoc("sweet and hot")

chilliChoc.eat
chilliChoc.describeTaste
