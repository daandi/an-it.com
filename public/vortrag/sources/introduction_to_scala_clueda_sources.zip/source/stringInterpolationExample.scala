val names = List("Roger","Felix", "Bene")

for (name <- names) println(s"Hello $name")

for (name <- names) println("Hello" + name)

for (name <- names) println(
s"""Hello $name your name
    has length:${ name.size }
    and reads backwards as:"${ name.reverse}"
"""
)
