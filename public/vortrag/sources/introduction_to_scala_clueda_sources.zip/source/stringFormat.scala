def euroToDollar(euro: Double): Double = euro * 1.352065

val euro = List(1,2.5,5.12)

euro map euroToDollar foreach { d =>
  println(f"Got $d%2.2f ($d)")
}
