object PimpString {
    
    class WeatherString(s: String) {
        def ☀ { println(s"$s sunny!") }
        def ☁ = "Dont't forget your ☂!"
    }
    
    implicit class ♔(name : String) {
        def hail = "Hail to king $name"
    }
    
    implicit def pimpString(in: String) : WeatherString = 
    	new WeatherString(in)
}