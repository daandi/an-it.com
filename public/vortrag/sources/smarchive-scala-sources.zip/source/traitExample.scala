trait Edible {
	def taste: String
	def eat = println(taste)
}

trait exoticTaste {
	def eat: Unit
	def describeTaste = {
		eat
		println("It tastes exotic")
	}
}

case class Cake extends Edible{
	def taste = "sweet"
}

case class ChilliChoclate extends Edible with exoticTaste{
	val taste = "sweet and hot"
}

val cake = new Cake
cake.eat

val chilliChoc = new ChilliChoclate
chilliChoc.eat
chilliChoc.describeTaste


