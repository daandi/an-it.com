import scala.io.Source

val html = Source.fromURL("http://www.an-it.com").getLines.mkString("")

val urlExtractor = """href\s?=\s?"([^"]+)"""".r
for {
	urlExtractor(url) <- (urlExtractor findAllIn html).matchData
	} {
	println("Url ->" + url)
	
}

