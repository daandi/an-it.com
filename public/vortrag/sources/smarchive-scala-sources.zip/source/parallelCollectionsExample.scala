(1 to 10).foreach(println)
(1 to 10).par.foreach(println)

val tenTimes = (1 to 10).par.map(_ * 10)
val tenTimesOrdered = tenTimes.seq