object ControlStructures {
  def unless( test: => Boolean)(action: => Any) = if (! test) {action}
  def times( n: Int )(action: => Unit) {
    (1 to n).foreach { i => action}
  }
}