trait StorageComponent {
	
	val store: Storage
	
	trait Storage {
		def storeValue(toStore: String)
		def storedValues : Seq[String]
	}
}

trait TerminalComponent {

	val terminal: Terminal
	
	trait Terminal {
		def out(s: String) : Unit
	}
}

trait TerminalStorageComponent {
	self : StorageComponent with TerminalComponent =>
	
	val cl : TerminalStorage = new TerminalStorage
	
	class TerminalStorage{
	
		def safe(s : String ) = {
			store.storeValue(s)
			terminal.out("Stored " + s)
		}
	
		def printHistory {	terminal.out(store.storedValues.mkString(" "))}
		def history : Seq[String]= store.storedValues
		
	}
}

