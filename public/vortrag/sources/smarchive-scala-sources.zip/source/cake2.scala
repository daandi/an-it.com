class TerminalWithHistory extends TerminalStorageComponent with TerminalComponent with StorageComponent{
	val store = new Storage {
		var listStore = List[String]()
	
		def storeValue(s: String) { listStore = s :: listStore }
		def storedValues = listStore
	}
	
	val terminal = new Terminal {
		def out(s : String) { println(s)}
	}

}