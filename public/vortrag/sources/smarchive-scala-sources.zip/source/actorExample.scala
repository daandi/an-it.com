import scala.actors._
import scala.actors.Actor._

case class Comedy(who: String)
case class Drama(who: String)

class StageActor() extends Actor {
  def act() {
    loop {
      react {
        case Drama(who) => {
		  println(who + ": To be ..." )
		  println(who + ": or not To be" )
        }
        case Comedy(who) => {
          println(who + ": Knock, Knock")
          println("Someone: Who's there?")
		  println(who + "Honey bee. ")
		  println("Someone: Honey bee who?")
		  println(who + "Honey bee a dear and get me a beer.")
        }
      }
    }
  }
}

val artist = new StageActor().start
val clown = new StageActor().start
println("Action.")
artist ! Drama("Artistical")
clown ! Comedy("Clown")
clown ! Drama("Clown")
artist ! Comedy("Art")
