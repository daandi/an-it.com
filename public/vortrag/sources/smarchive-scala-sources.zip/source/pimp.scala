object PimpString {
	
	class WeatherString(s: String) {
		def ☀ {
			println(s + " sunny!")
		}
		
		def ☁ = "Dont't forget your ☂"
	}
	
	class ♔(name : String) {
		def hail = "Hail to king " + name
	
	}
	
	implicit def pimpString(in: String) : WeatherString = new WeatherString(in)
	implicit def roayalify(in: String) : ♔ = new ♔(in)
}